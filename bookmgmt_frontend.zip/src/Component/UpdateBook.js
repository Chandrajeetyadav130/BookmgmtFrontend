const UpdateBook=()=>{
    return(
        <>
        <h1>Bookslist</h1>
        </>
    )
}
export default UpdateBook